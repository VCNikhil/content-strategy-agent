"""Content Strategy Agent - long-term content memory powered by Hindsight.

Run (light theme recommended):
  streamlit run app.py --server.fileWatcherType none --theme.base light

Hindsight Cloud:  HINDSIGHT_URL=https://api.hindsight.vectorize.io  HINDSIGHT_API_KEY=hsk_...
Local embedded:   USE_EMBEDDED=1  LLM_PROVIDER / LLM_MODEL / LLM_API_KEY
Optional:         BANK_ID=acme-demo  (use a fresh bank for a clean before/after recording)
"""
import os
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

import pandas as pd
import streamlit as st
from hindsight_client import Hindsight

from seed_data import NEW_POST, POSTS, to_text

BANK = os.getenv("BANK_ID", "acme-content")
URL = os.getenv("HINDSIGHT_URL", "http://localhost:8888")
EMBEDDED = os.getenv("USE_EMBEDDED") == "1" and not os.getenv("HINDSIGHT_API_KEY")

st.set_page_config(page_title="Content Strategy Agent", page_icon="🧠", layout="wide")

# ----------------------------------------------------------------------------
# Styling
# ----------------------------------------------------------------------------
st.markdown(
    """
<style>
@import url('https://fonts.googleapis.com/css2?family=Newsreader:wght@500;600&family=Source+Sans+3:wght@400;500;600&display=swap');

:root {
  --ink: #12203A;
  --muted: #5A6A80;
  --paper: #F2F5F9;
  --surface: #FFFFFF;
  --line: #DCE3EC;
  --teal: #0F766E;
  --teal-soft: #E3F2F0;
  --amber: #D97706;
  --amber-soft: #FDF1DC;
}

.stApp { background: var(--paper); color: var(--ink); font-family: 'Source Sans 3', system-ui, sans-serif; }
.stApp p, .stApp li, .stApp label, .stApp span, .stApp div { color: inherit; }
h1, h2, h3, h4 { font-family: 'Newsreader', Georgia, serif !important; color: var(--ink) !important; letter-spacing: -0.01em; }

/* hide Streamlit chrome we don't need */
[data-testid="stToolbar"], .stAppDeployButton, #MainMenu, footer { display: none !important; }
.block-container { padding-top: 2.2rem; max-width: 1280px; }

/* sidebar */
[data-testid="stSidebar"] { background: var(--surface); border-right: 1px solid var(--line); }
[data-testid="stSidebar"] * { color: var(--ink); }

/* hero */
.hero { padding: 0.4rem 0 1.2rem 0; }
.hero h1 { font-size: 2.6rem; line-height: 1.1; margin: 0 0 0.5rem 0; }
.hero p { font-size: 1.1rem; color: var(--muted) !important; max-width: 62ch; margin: 0; line-height: 1.5; }
.status { display: inline-flex; align-items: center; gap: 0.5rem; margin-top: 0.9rem; padding: 0.3rem 0.75rem;
  border: 1px solid var(--line); border-radius: 999px; background: var(--surface); font-size: 0.85rem; color: var(--muted); }
.dot { width: 8px; height: 8px; border-radius: 50%; background: var(--teal); display: inline-block; }

/* metrics */
[data-testid="stMetric"] { background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 0.9rem 1.1rem; }
[data-testid="stMetricLabel"] p { color: var(--muted) !important; font-size: 0.9rem; }
[data-testid="stMetricValue"] { font-family: 'Newsreader', Georgia, serif; font-size: 2rem; color: var(--ink); }

/* tabs */
.stTabs [data-baseweb="tab-list"] { gap: 1.6rem; border-bottom: 1px solid var(--line); }
.stTabs [data-baseweb="tab"] { padding: 0.6rem 0.1rem; font-weight: 600; color: var(--muted); }
.stTabs [aria-selected="true"] { color: var(--teal) !important; }
.stTabs [data-baseweb="tab-highlight"] { background-color: var(--teal) !important; }

/* buttons */
.stButton > button { border-radius: 8px; border: 1px solid var(--line); background: var(--surface); color: var(--ink); font-weight: 600; }
.stButton > button:hover { border-color: var(--teal); color: var(--teal); }
.stButton > button[kind="primary"] { background: var(--teal); border-color: var(--teal); color: #fff; }
.stButton > button[kind="primary"]:hover { background: #0B5F59; color: #fff; }

/* result containers */
[data-testid="stVerticalBlockBorderWrapper"] { background: var(--surface); border-radius: 12px; }
.result-note { color: var(--muted); font-size: 0.85rem; margin-bottom: 0.4rem; }
.learned { background: var(--amber-soft); border-left: 3px solid var(--amber); padding: 0.5rem 0.8rem; border-radius: 6px; font-size: 0.92rem; }
.mem { padding: 0.55rem 0; border-bottom: 1px solid var(--line); line-height: 1.45; }
.mem:last-child { border-bottom: none; }
h3 { font-size: 1.35rem !important; }
</style>
""",
    unsafe_allow_html=True,
)


# ----------------------------------------------------------------------------
# Hindsight client (one long-lived worker thread; see notes in README)
# ----------------------------------------------------------------------------
class ThreadedClient:
    """Run every Hindsight call on one persistent thread so the client's HTTP session
    always uses the same event loop, never the one Streamlit already runs."""

    def __init__(self, client):
        self._c = client
        self._ex = ThreadPoolExecutor(max_workers=1, thread_name_prefix="hindsight")

    def __getattr__(self, name):
        attr = getattr(self._c, name)
        if not callable(attr):
            return attr

        def run(*args, **kwargs):
            return self._ex.submit(attr, *args, **kwargs).result()

        return run


@st.cache_resource
def get_client():
    if EMBEDDED:
        from hindsight import HindsightServer

        server = HindsightServer(
            llm_provider=os.getenv("LLM_PROVIDER", "openai"),
            llm_model=os.getenv("LLM_MODEL", "gpt-5-mini"),
            llm_api_key=os.environ["LLM_API_KEY"],
        )
        server.__enter__()
        return ThreadedClient(Hindsight(base_url=server.url))
    api_key = os.getenv("HINDSIGHT_API_KEY")
    kwargs = {"api_key": api_key} if api_key else {}
    return ThreadedClient(Hindsight(base_url=URL, **kwargs))


def as_text(resp):
    """Be defensive about response shapes across client versions."""
    for attr in ("text", "answer", "content", "response"):
        val = getattr(resp, attr, None)
        if isinstance(val, str) and val.strip():
            return val
    if isinstance(resp, dict):
        for key in ("text", "answer", "content", "response"):
            if resp.get(key):
                return resp[key]
    return str(resp)


def call_with_retry(fn, attempts=6, **kwargs):
    """Retry temporary provider errors (503 overloaded, 429 rate limit) with backoff."""
    for i in range(attempts):
        try:
            return fn(**kwargs)
        except Exception as e:
            msg = str(e)
            temporary = any(k in msg for k in ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "high demand"))
            if temporary and i < attempts - 1:
                time.sleep(5 * (i + 1))
                continue
            raise


def friendly(e):
    msg = str(e)
    if "401" in msg or "403" in msg:
        return "Hindsight or the model provider rejected the API key. Check HINDSIGHT_API_KEY (or LLM_API_KEY) and restart."
    if "429" in msg or "RESOURCE_EXHAUSTED" in msg:
        return "The model provider's rate limit or quota is used up. Wait a minute and try again."
    if "503" in msg or "UNAVAILABLE" in msg:
        return "The model provider is busy right now. Try again in a minute."
    return f"Something went wrong: {msg[:300]}"


def retain(client, post):
    call_with_retry(
        client.retain,
        bank_id=BANK,
        content=to_text(post),
        context="content calendar and performance",
        timestamp=f"{post[0]}T09:00:00Z",
    )


# ----------------------------------------------------------------------------
# Session state
# ----------------------------------------------------------------------------
ss = st.session_state
ss.setdefault("posts", list(POSTS))  # local copy, used only for the charts and numbers
ss.setdefault("loaded", 0)
ss.setdefault("seeded", False)
ss.setdefault("runs", {})  # analysis key -> list of runs, so we can compare before and after
ss.setdefault("learned", [])  # titles added during this session

client = get_client()


def posts_df():
    df = pd.DataFrame(ss.posts, columns=["date", "format", "title", "topic", "voice", "views", "shares"])
    df["date"] = pd.to_datetime(df["date"])
    return df


# ----------------------------------------------------------------------------
# Sidebar
# ----------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### Memory")
    where = "Local embedded server" if EMBEDDED else URL
    st.caption(f"Server: {where}")
    st.caption(f"Memory bank: {BANK}")

    already = st.checkbox("Sample posts are already in this bank", value=ss.seeded)
    if already:
        ss.seeded = True

    if st.button("Load 18 sample posts", disabled=ss.seeded, use_container_width=True):
        progress = st.progress(0.0, text="Starting...")
        start = ss.get("loaded", 0)
        try:
            for idx in range(start, len(POSTS)):
                retain(client, POSTS[idx])
                ss.loaded = idx + 1
                progress.progress((idx + 1) / len(POSTS), text=f"Retained {idx + 1} of {len(POSTS)}")
            ss.seeded = True
            st.success("Sample posts loaded.")
        except Exception as e:
            st.error(friendly(e))
            st.caption("Click the button again to continue from where it stopped.")

    st.divider()
    st.markdown("### Publish a new post")
    st.caption("Add a post the agent hasn't seen. It retains it, and later answers can use it.")
    with st.form("new_post"):
        title = st.text_input("Title", NEW_POST[2])
        c1, c2 = st.columns(2)
        fmt = c1.selectbox("Format", ["blog", "video", "linkedin", "twitter", "whitepaper"])
        date = c2.text_input("Date", NEW_POST[0])
        topic = st.text_input("Topic", NEW_POST[3])
        voice = st.text_input("Voice", NEW_POST[4])
        c3, c4 = st.columns(2)
        views = c3.number_input("Views", value=NEW_POST[5], step=100)
        shares = c4.number_input("Shares", value=NEW_POST[6], step=10)
        submitted = st.form_submit_button("Publish and let the agent learn", type="primary", use_container_width=True)
    if submitted:
        with st.spinner("Retaining..."):
            try:
                post = (date, fmt, title, topic, voice, int(views), int(shares))
                retain(client, post)
                ss.posts.append(post)
                ss.learned.append(title)
                st.success("Retained. Give it a minute, then run an analysis again.")
            except Exception as e:
                st.error(friendly(e))

    if ss.learned:
        st.divider()
        st.markdown("### Learned this session")
        for t in ss.learned:
            st.markdown(f'<div class="learned">{t}</div>', unsafe_allow_html=True)


# ----------------------------------------------------------------------------
# Hero and numbers
# ----------------------------------------------------------------------------
st.markdown(
    f"""
<div class="hero">
  <h1>What has our content taught us?</h1>
  <p>A content strategy agent with long-term memory. It remembers every post you published and how it performed, then tells you what to make next.</p>
  <span class="status"><span class="dot"></span>Memory connected, bank {BANK}</span>
</div>
""",
    unsafe_allow_html=True,
)

df = posts_df()
by_format = df.groupby("format")["views"].mean().round().sort_values(ascending=False)
share_rate = df["shares"].sum() / max(df["views"].sum(), 1) * 1000

m1, m2, m3, m4 = st.columns(4)
m1.metric("Posts in memory", len(df))
m2.metric("Total views", f"{int(df['views'].sum()):,}")
m3.metric("Shares per 1,000 views", f"{share_rate:.1f}")
m4.metric("Best format by average views", by_format.index[0] if len(by_format) else "none")

ch1, ch2 = st.columns(2)
with ch1:
    st.markdown("### Average views by format")
    st.bar_chart(by_format, color="#0F766E", height=240)
with ch2:
    st.markdown("### Views over time")
    st.line_chart(df.set_index("date")["views"].sort_index(), color="#12203A", height=240)

st.markdown("&nbsp;", unsafe_allow_html=True)


# ----------------------------------------------------------------------------
# Analyses
# ----------------------------------------------------------------------------
def analysis_panel(key, button_label, query, spinner_text):
    if st.button(button_label, key=f"btn_{key}", type="primary"):
        with st.spinner(spinner_text):
            try:
                r = call_with_retry(client.reflect, bank_id=BANK, query=query)
                ss.runs.setdefault(key, []).append(
                    {"time": datetime.now().strftime("%H:%M:%S"), "text": as_text(r), "posts": len(ss.posts)}
                )
            except Exception as e:
                st.error(friendly(e))

    runs = ss.runs.get(key, [])
    if not runs:
        st.info(f"Press the button above. The agent will read your memory and write this analysis.")
        return

    latest = runs[-1]
    with st.container(border=True):
        st.markdown(
            f'<div class="result-note">Run at {latest["time"]}, with {latest["posts"]} posts known to this session</div>',
            unsafe_allow_html=True,
        )
        st.markdown(latest["text"])

    if len(runs) > 1:
        prev = runs[-2]
        with st.expander("Compare with the previous run", expanded=False):
            left, right = st.columns(2)
            with left:
                st.markdown(f"**Before** (run at {prev['time']}, {prev['posts']} posts)")
                st.markdown(prev["text"])
            with right:
                st.markdown(f"**After** (run at {latest['time']}, {latest['posts']} posts)")
                st.markdown(latest["text"])


def dedupe(texts):
    seen, out = set(), []
    for t in texts:
        key = t.split("|")[0].strip().lower()
        if key not in seen:
            seen.add(key)
            out.append(t)
    return out


tab1, tab2, tab3, tab4 = st.tabs(["Coverage gaps", "Brand voice", "What to publish next", "Ask memory"])

with tab1:
    st.markdown("### Where are the gaps?")
    st.caption("Topics and formats that are over-used, under-used or missing, with the posts behind each claim.")
    analysis_panel(
        "gaps",
        "Find coverage gaps",
        "Based on everything we have published, which topics and formats are we under-covering or "
        "missing entirely, and which are over-saturated? Cite specific posts and metrics.",
        "Reading your whole content history...",
    )

with tab2:
    st.markdown("### How has our voice changed?")
    st.caption("Month by month, which voice performs best, and how we sound today.")
    analysis_panel(
        "voice",
        "Analyze brand voice",
        "How has our brand voice evolved over time, month by month? Which voice performs best and "
        "which performs worst? Describe our current voice in 3 sentences.",
        "Tracing your brand voice over time...",
    )

with tab3:
    st.markdown("### What should we publish next week?")
    st.caption("Three recommendations, each backed by posts from your own history.")
    analysis_panel(
        "next",
        "Recommend next week's content",
        "Recommend 3 pieces of content to publish next week. For each give topic, format, voice, and "
        "the evidence from our past performance justifying it.",
        "Planning next week's content...",
    )

with tab4:
    st.markdown("### Ask your memory")
    st.caption("Ask about any post, topic or result. Try asking about something you haven't published yet, then publish it and ask again.")
    q = st.text_input("Your question", "Have we published anything on security or prompt injection?")
    style = st.radio("Show me", ["Matching memories", "A written answer"], horizontal=True)
    if st.button("Search memory", type="primary"):
        with st.spinner("Searching..."):
            try:
                if style == "A written answer":
                    r = call_with_retry(client.reflect, bank_id=BANK, query=q)
                    with st.container(border=True):
                        st.markdown(as_text(r))
                else:
                    res = call_with_retry(client.recall, bank_id=BANK, query=q)
                    items = getattr(res, "results", res)
                    texts = dedupe([as_text(i) for i in items])
                    if not texts:
                        st.info("Nothing in memory matches that question yet.")
                    else:
                        learned = [t.lower() for t in ss.learned]
                        st.caption(f"{len(texts)} distinct memories found. The closest matches are first.")
                        with st.container(border=True):
                            for t in texts[:6]:
                                new = any(x in t.lower() for x in learned)
                                badge = ":orange-badge[Learned this session] " if new else ""
                                st.markdown(f"{badge}{t}")
                        if len(texts) > 6:
                            with st.expander(f"Show the other {len(texts) - 6}"):
                                for t in texts[6:]:
                                    st.markdown(f"- {t}")
            except Exception as e:
                st.error(friendly(e))
