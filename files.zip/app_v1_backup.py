"""Content Strategy Agent - powered by Hindsight memory.

Run:  streamlit run app.py
Uses a Hindsight server at HINDSIGHT_URL (default http://localhost:8888).
If nothing is running there, set USE_EMBEDDED=1 to start an embedded server
(needs `pip install hindsight-all` and OPENAI_API_KEY).
"""
import os

import streamlit as st
from hindsight_client import Hindsight

from seed_data import NEW_POST, POSTS, to_text


from concurrent.futures import ThreadPoolExecutor


class ThreadedClient:
    """Run every Hindsight call in a fresh thread so the client's own event loop
    never collides with the loop already running inside Streamlit."""

    def __init__(self, client):
        self._c = client
        # ONE long-lived worker thread: the client's HTTP session is bound to the
        # event loop of the thread that first uses it, so every call must reuse it.
        self._ex = ThreadPoolExecutor(max_workers=1, thread_name_prefix="hindsight")

    def __getattr__(self, name):
        attr = getattr(self._c, name)
        if not callable(attr):
            return attr

        def run(*args, **kwargs):
            return self._ex.submit(attr, *args, **kwargs).result()

        return run


BANK = "acme-content"
URL = os.getenv("HINDSIGHT_URL", "http://localhost:8888")

st.set_page_config(page_title="Content Strategy Agent", page_icon="🧠", layout="wide")


@st.cache_resource
def get_client():
    if os.getenv("USE_EMBEDDED") == "1" and not os.getenv("HINDSIGHT_API_KEY"):
        from hindsight import HindsightServer

        server = HindsightServer(
            llm_provider=os.getenv("LLM_PROVIDER", "openai"),
            llm_model=os.getenv("LLM_MODEL", "gpt-5-mini"),
            llm_api_key=os.environ["LLM_API_KEY"],
        )
        server.__enter__()  # keep alive for the Streamlit process
        return ThreadedClient(Hindsight(base_url=server.url))
    # Hindsight Cloud (or any remote server): auth with a Hindsight key, no LLM key needed.
    api_key = os.getenv("HINDSIGHT_API_KEY")
    kwargs = {"api_key": api_key} if api_key else {}
    return ThreadedClient(Hindsight(base_url=URL, **kwargs))


def as_text(resp):
    """Be defensive about response shapes across client versions."""
    for attr in ("text", "answer", "content", "response"):
        val = getattr(resp, attr, None)
        if isinstance(val, str) and val.strip():
            return val
    if isinstance(resp, dict):
        for key in ("text", "answer", "content", "response"):
            if resp.get(key):
                return resp[key]
    return str(resp)


def retain(client, post, attempts=6):
    """Retain one post, retrying with backoff on temporary LLM errors (503/429)."""
    import time

    for i in range(attempts):
        try:
            client.retain(
                bank_id=BANK,
                content=to_text(post),
                context="content calendar and performance",
                timestamp=f"{post[0]}T09:00:00Z",
            )
            return
        except Exception as e:
            msg = str(e)
            temporary = any(k in msg for k in ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "high demand"))
            if temporary and i < attempts - 1:
                time.sleep(5 * (i + 1))
                continue
            raise


client = get_client()
if "seeded" not in st.session_state:
    st.session_state.seeded = False
    st.session_state.log = []

# ---------------- Sidebar ----------------
with st.sidebar:
    st.title("🧠 Content Strategy Agent")
    st.caption("Memory by Hindsight")
    _mode = "embedded (local)" if (os.getenv("USE_EMBEDDED") == "1" and not os.getenv("HINDSIGHT_API_KEY")) else URL
    st.caption(f"Connected to: {_mode}")
    if st.button("1. Load 18 past posts into memory", disabled=st.session_state.seeded):
        progress = st.progress(0.0, text="Retaining posts (LLM extracts facts, entities, timeline)...")
        start = st.session_state.get("loaded", 0)  # resume where a failed run stopped
        for idx in range(start, len(POSTS)):
            retain(client, POSTS[idx])
            st.session_state.loaded = idx + 1
            progress.progress((idx + 1) / len(POSTS), text=f"Retained {idx + 1}/{len(POSTS)}")
        st.session_state.seeded = True
        st.success("Memory loaded.")

    st.divider()
    st.markdown("**Add a new post**")
    with st.form("new_post"):
        title = st.text_input("Title", NEW_POST[2])
        fmt = st.selectbox("Format", ["blog", "video", "linkedin", "twitter", "whitepaper"])
        topic = st.text_input("Topic", NEW_POST[3])
        voice = st.text_input("Voice", NEW_POST[4])
        date = st.text_input("Date (YYYY-MM-DD)", NEW_POST[0])
        views = st.number_input("Views", value=NEW_POST[5])
        shares = st.number_input("Shares", value=NEW_POST[6])
        if st.form_submit_button("2. Publish and let the agent learn"):
            with st.spinner("Retaining..."):
                retain(client, (date, fmt, title, topic, voice, int(views), int(shares)))
            st.success("Retained. Re-run an analysis to see beliefs change.")

# ---------------- Main ----------------
st.header("What has our content taught us?")

tab1, tab2, tab3, tab4 = st.tabs(
    ["Coverage gaps", "Brand voice evolution", "What to publish next", "Ask memory"]
)

with tab1:
    if st.button("Find coverage gaps"):
        with st.spinner("Reflecting over all past content..."):
            r = client.reflect(
                bank_id=BANK,
                query=(
                    "Based on everything we have published, which topics and formats are "
                    "we under-covering or missing entirely, and which are over-saturated? "
                    "Cite specific posts and metrics."
                ),
            )
        st.markdown(as_text(r))

with tab2:
    if st.button("Analyze brand voice"):
        with st.spinner("Reflecting..."):
            r = client.reflect(
                bank_id=BANK,
                query=(
                    "How has our brand voice evolved over time, month by month? "
                    "Which voice performs best and which performs worst? "
                    "Describe our current voice in 3 sentences."
                ),
            )
        st.markdown(as_text(r))

with tab3:
    if st.button("Recommend next week's content"):
        with st.spinner("Reflecting..."):
            r = client.reflect(
                bank_id=BANK,
                query=(
                    "Recommend 3 pieces of content to publish next week. For each give topic, "
                    "format, voice, and the evidence from our past performance justifying it."
                ),
            )
        st.markdown(as_text(r))

with tab4:
    q = st.text_input("Ask anything about past content", "Which format got the most views?")
    if st.button("Recall"):
        with st.spinner("Recalling..."):
            res = client.recall(bank_id=BANK, query=q)
        items = getattr(res, "results", res)
        try:
            for it in items:
                st.markdown(f"- {as_text(it)}")
        except TypeError:
            st.markdown(as_text(res))

st.divider()
st.caption(
    "Demo flow: run 'Find coverage gaps' (security shows up as missing) -> publish the "
    "security post from the sidebar -> run it again and watch the answer change."
)
